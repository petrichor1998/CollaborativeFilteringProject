#Submitted by Parth Padalkar UTD ID = 2021473758

######################################################

TOTAL RUNTIME : 15 MINS (on csgrads1.utdallas.edu)

#####################################################

extract the folder and run the file as follows:

-train_data "address of train file"
-test_data "address of test file"

python collaborative_filtering.py -train_data "netflix/TrainingRatings.txt" -test_data "netflix/TestingRatings.txt"

